<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

class Mensagem {
  private $para = null;
  private $assunto = null;
  private $mensagem = null;
  public $status = ['codigo_status' => null, 'descricao_status' => ''];

  public function __get($atributo) {
    return $this->$atributo;
  }

  public function __set($atributo, $valor) {
    $this->$atributo = $valor;
  }

  public function mensagemValida() {
    return !(empty($this->para) || empty($this->assunto) || empty($this->mensagem));
  }
}

$mensagem = new Mensagem();

$mensagem->__set('para', $_POST['para'] ?? '');
$mensagem->__set('assunto', $_POST['assunto'] ?? '');
$mensagem->__set('mensagem', $_POST['mensagem'] ?? '');

if (!$mensagem->mensagemValida()) {
  $mensagem->status['codigo_status'] = 2;
  $mensagem->status['descricao_status'] = 'Mensagem não é válida: preencha todos os campos obrigatórios.';
} else {
  $mail = new PHPMailer(true);

  try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'isaiasmucola@gmail.com';
    $mail->Password = 'xglv xjkt ijon inax';//senha gerada pelo google
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    $mail->setFrom('isaiasmucola@gmail.com', 'MailPro App');
    $mail->addAddress($mensagem->__get('para'));

    $mail->isHTML(true);
    $mail->Subject = $mensagem->__get('assunto');
    $mail->Body = $mensagem->__get('mensagem');
    $mail->AltBody = strip_tags($mensagem->__get('mensagem'));

    $mail->send();

    $mensagem->status['codigo_status'] = 1;
    $mensagem->status['descricao_status'] = 'E-mail enviado com sucesso!';
  } catch (Exception $e) {
    $mensagem->status['codigo_status'] = 2;
    $mensagem->status['descricao_status'] = 'Erro ao enviar o e-mail: ' . $mail->ErrorInfo;
  }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="utf-8" />
  <title>MailPro - Resultado</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <div class="container my-5">
    <div class="text-center mb-4">
      <img class="d-block mx-auto mb-3" src="logo.png" alt="Logo" width="64" height="64">
      <h2 class="fw-bold text-primary">MailPro</h2>
      <p class="text-muted">Seu app moderno de envio de e-mails!</p>
    </div>

    <?php if ($mensagem->status['codigo_status'] == 1): ?>
      <div class="text-center">
        <h1 class="display-4 text-success">Sucesso</h1>
        <p class="lead"><?= $mensagem->status['descricao_status'] ?></p>
        <a href="index.php" class="btn btn-success btn-lg mt-4">Voltar</a>
      </div>
    <?php elseif ($mensagem->status['codigo_status'] == 2): ?>
      <div class="text-center">
        <h1 class="display-4 text-danger">Erro</h1>
        <p class="lead"><?= $mensagem->status['descricao_status'] ?></p>
        <a href="index.php" class="btn btn-danger btn-lg mt-4">Voltar</a>
      </div>
    <?php endif; ?>
  </div>
</body>
</html>