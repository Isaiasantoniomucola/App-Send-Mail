<html>
	<head>
		<meta charset="utf-8" />
    	<title>App Mail Send</title>

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    	

	</head>

	<body>		

<div class="container my-5">  
  <div class="text-center mb-4">
    <img class="d-block mx-auto mb-3" src="logo.png" alt="Logo" width="64" height="64">
    <h2 class="fw-bold text-primary">MailPro</h2>
    <p class="text-muted">Seu app moderno de envio de e-mails!</p>
  </div>

  <div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
      <div class="card shadow-sm border-0">
        <div class="card-body">
          <form action="processa_envio.php" method="post">
            <div class="mb-3">
              <label for="para" class="form-label">Para</label>
              <input name="para" type="email" class="form-control form-control-sm" id="para" placeholder="ex: isaias@dominio.com.ao">
            </div>

            <div class="mb-3">
              <label for="assunto" class="form-label">Assunto</label>
              <input name="assunto" type="text" class="form-control form-control-sm" id="assunto" placeholder="Assunto do e-mail">
            </div>

            <div class="mb-3">
              <label for="mensagem" class="form-label">Mensagem</label>
              <textarea name="mensagem" class="form-control form-control-sm" id="mensagem" rows="5" placeholder="Digite sua mensagem..."></textarea>
            </div>

            <div class="d-grid">
              <button type="submit" class="btn btn-primary btn-sm">Enviar Mensagem</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

	</body>
</html>